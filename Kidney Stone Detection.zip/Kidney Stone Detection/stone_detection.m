clc
clear all
close all
warning off
originalimg = imread('Kidney with stone/1.jpg');
figure;
subplot(3,3,1);
imshow(originalimg);
title("Original Image");

grayimg = rgb2gray(originalimg);
subplot(3,3,2);
imshow(grayimg);impixelinfo;
title("Gray Scale Image");
%Thresolding, pixel value greater than 20 is equal to 1 and less than 20 is
%equal to 0
binaryimg = imbinarize(grayimg,20/255); 
subplot(3,3,3);
imshow(binaryimg);
title("Binary Image with thresold 20");

%Creating the mask
mask = imfill(binaryimg,'holes'); %filling the holes in area of kidney
%removing the unwanted area 
mask = bwareaopen(mask,1000);
subplot(3,3,4);
imshow(mask);
title("Mask");

%applying mask to the gray scale image
img = uint8(double(grayimg).*double(mask));%uint8(double(originalimg).*repmat(mask,[1 1 3]));
subplot(3,3,5);
imshow(img);
title("Preprocessed Image");

%contrast streaching
img = imadjust(img,[0.3 0.7],[]); 
subplot(3,3,6);imshow(img);title("Contrast streaching");
%applying median filter
img = medfilt2(img,[5 5]);
subplot(3,3,7);imshow(img);title("Applied Median filter");
%Thresolding, pixel value greater than 250 is equal to 1 and less than 250
%is equal to 0
img = img>250;
subplot(3,3,8);imshow(img);title("Thresolding with value 250")

%creating filter to detect the stone in kidney
%The stone lies mostly in center part of the kidney
[r, c, m] = size(img); 
x = r/2;
y = c/3;
row = [x x+200 x+200 x];
col = [y y y+40 y+40];
filter = roipoly(img,row,col);
subplot(3,3,9);imshow(filter);title("filter");

finalimg = img.*double(filter);
figure;imshow(finalimg);title("Final Image")
output = bwareaopen(finalimg,4);
[ya, number] = bwlabel(output);
if(number>=1)
    disp('stone is detected');
else
    disp('No stone is detected');
end



